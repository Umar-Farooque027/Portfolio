DATA ANALYST PORTFOLIO — Umar Farooque Ansari

1. Open this folder in VS Code.
2. Put your real resume PDF in this folder and name it: resume.pdf
3. Open index.html in Chrome, or use VS Code Live Server.
4. Update any project links/details you want in index.html.
5. Your LinkedIn/GitHub/email links are already included.

Files:
- index.html
- style.css
- script.js
- resume.pdf (add your own PDF)
